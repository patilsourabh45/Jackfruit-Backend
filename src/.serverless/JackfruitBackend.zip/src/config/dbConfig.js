const DbConfig = {
    USERNAME: 'patilsourabh46',
    PASSWORD: 'PATILSJP',
    CLUSTER_ADDRESS: 'cluster0.jkqng.mongodb.net',
    DATABASE_NAME:'Jackfruit',
  };
  
  module.exports = DbConfig;