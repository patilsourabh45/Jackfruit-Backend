const AuthErrorCodes = { 
    INVALID_EMAIL: 'INVALID_EMAIL',
    INVALID_PASSWORD: 'INVALID_PASSWORD'
  };
  
  module.exports = {
    AuthErrorCodes: AuthErrorCodes
  };